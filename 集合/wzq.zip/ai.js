﻿//策略
var ai_x = 0;
var ai_y = 0;
var row = 12;
var col = 12;
//判断范围
function isIn(x, y) {
    return (0 <= x && x < col && 0 <= y && y < row);
}
//策略
function getPos(boardset, who) {
    var x = 0;
    var y = 0;
    var val = 0;
    var maxVal = -1;
    for (var j = 0; j < row; ++j)
        for (var i = 0; i < col; ++i) {
            if (boardset[j][i] > 0)
                continue;
            var val = getMyVal(boardset, who, i, j);
            if (val > maxVal) {
                found = true;
                maxVal = val;
                x = i;
                y = j;
            }
            val = getMyVal(boardset, 3 - who, i, j) - 5;
            if (val <= 0)
                val = -1;
            if (val > maxVal) {
                found = true;
                maxVal = val;
                x = i;
                y = j;
            }
        }
    ai_x = x;
    ai_y = y;
}
//估价
function getMyVal(boardset, who, x, y) {
    var val = 0;
    var dirX = [-1, 0, 1, -1];
    var dirY = [-1, -1, -1, 0];
    for (var i = 0; i < 4; ++i) {
        var num = 1;
        var kong1 = false;
        var kong2 = false;
        for (var j = 1; j < 5; ++j) {
            var dx = x + dirX[i] * j;
            var dy = y + dirY[i] * j;
            if (isIn(dx, dy)) {
                if (boardset[dy][dx] == who)
                    ++num;
                else {
                    if (boardset[dy][dx] == 0)
                        kong1 = true;
                    break;
                }
            }
	    else {
		break;
	    }
        }
        for (var j = 1; j < 5; ++j) {
            var dx = x - dirX[i] * j;
            var dy = y - dirY[i] * j;
            if (isIn(dx, dy)) {
                if (boardset[dy][dx] == who)
                    ++num;
                else {
                    if (boardset[dy][dx] == 0)
                        kong2 = true;
                    break;
                }
            }
	    else {
		break;
	    }
        }
        if (num <= 1) {
            if (kong1 && kong2)
                val += 2;
            else if (kong1 || kong2)
                val += 1;
        }
        else if (num <= 2) {
            if (kong1 && kong2)
                val += 8;
            else if (kong1 || kong2)
                val += 3;
        }
        else if (num <= 3) {
            if (kong1 && kong2)
                val += 30;
            else if (kong1 || kong2)
                val += 10;
        }
        else if (num <= 4) {
            if (kong1 && kong2)
                val += 1000;
            else if (kong1 || kong2)
                val += 30;
        }
        else {
            val += 10000;
        }
    }
    return val;
}
//接受信息，注意信息收发的格式
function getMes(e)
{
    //捕获信息
	var messageType = e.data.type; //收到的信息
	//信息分类处理
	switch (messageType)
	{
	    case ('mes'):
	        var boardset = e.data.boardset; //收到的信息
	        var who = e.data.who; //收到的信息
	        getPos(boardset, who);
            //发送信息
	        postMessage({
	            'type': 'order',
	            'x': ai_x,
	            'y': ai_y,
	            'who' : who
	        });
	        break;
	}
}
addEventListener("message", getMes, true);