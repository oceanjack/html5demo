//����
var ai_x = 0;
var ai_y = 0;
var row = 12;
var col = 12;
var nums = false;
var lives = false;
var aim = 4;
//�жϷ�Χ
function isIn(x, y) {
    return (0 <= x && x < col && 0 <= y && y < row);
}
//����
function getPos(boardset, who) {
    var x = 0;
    var y = 0;
    var val = 0;
    var maxVal = 0;
    var found = false;
    for (var j = 0; j < row; ++j)
        for (var i = 0; i < col; ++i) {
            if (boardset[j][i] > 0)
                continue;
            nums = false;
            lives = false;
            var val = getMyVal(boardset, who, i, j);
            if (lives == false && nums && val > maxVal) {
                found = true;
                maxVal = val;
                x = i;
                y = j;
            }
        }
    ai_x = x;
    ai_y = y;
    return found;
}
//����
function getMyVal(boardset, who, x, y) {
    var val = 0;
    var dirX = [-1, 0, 1, -1];
    var dirY = [-1, -1, -1, 0];
    for (var i = 0; i < 4; ++i) {
        var num = 1;
        var kong1 = false;
        var kong2 = false;
        for (var j = 1; j < 6; ++j) {
            var dx = x + dirX[i] * j;
            var dy = y + dirY[i] * j;
            if (isIn(dx, dy)) {
                if (boardset[dy][dx] == who)
                    ++num;
                else {
                    if (boardset[dy][dx] == 0)
                        kong1 = true;
                    break;
                }
            }
	        else {
		        break;
	        }
        }
        for (var j = 1; j < 6; ++j) {
            var dx = x - dirX[i] * j;
            var dy = y - dirY[i] * j;
            if (isIn(dx, dy)) {
                if (boardset[dy][dx] == who)
                    ++num;
                else {
                    if (boardset[dy][dx] == 0)
                        kong2 = true;
                    break;
                }
            }
	        else {
		        break;
	        }
        }
        if (!(kong1 && kong2) && num == aim) {
            nums = true;
        }
        if (num <= 1) {
            if (kong1 && kong2)
                val += 2;
            else if (kong1 || kong2)
                val += 1;
        }
        else if (num <= 2) {
            if (kong1 && kong2)
                val += 8;
            else if (kong1 || kong2)
                val += 3;
        }
        else if (num <= 3) {
            if (kong1 && kong2)
                val += 30;
            else if (kong1 || kong2)
                val += 10;
        }
        else if (num <= 4) {
            if (kong1 && kong2)
                val += 1000;
            else if (kong1 || kong2)
                val += 30;
        }
        else {
            val += 10000;
        }
    }
    return val;
}
//������Ϣ��ע����Ϣ�շ��ĸ�ʽ
function getMes(e)
{
    //������Ϣ
	var messageType = e.data.type; //�յ�����Ϣ
	//��Ϣ���ദ��
	switch (messageType)
	{
	    case ('mes'):
	        var boardset = e.data.boardset; //�յ�����Ϣ
	        var who = e.data.who; //�յ�����Ϣ
	        if (getPos(boardset, who) == false)
	            who = -1;
            //������Ϣ
	        postMessage({
	            'type': 'order',
	            'x': ai_x,
	            'y': ai_y,
	            'who' : who
	        });
	        break;
	}
}
addEventListener("message", getMes, true);