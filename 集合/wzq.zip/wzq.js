﻿//横竖
var row = 12;
var col = 12;
//图片资源
var blackImg = new Image();
blackImg.src = "image/z.png";
var whiteImg = new Image();
whiteImg.src = "image/z2.png";
var boardImg = new Image();
boardImg.src = "image/q.png";
//画布
var canvas;
var canvasVal;
//资源计数
var totCnt = 3;
var cnt = 0;
var first = 0; //黑白棋0黑
var timer; //超时器
var myTimer; //计时器
var alp = 0.0; //透明度
var end = false; //判断结束
//后台处理工具
/*
var getName = "hehe";
var getSrc = ["ai.js", "ai.js", "ai.js", ""];
var myName = "oceanjackzhu";
var mySrc = ["策略集/Center at first tiem.js",
    "策略集/Make live five.js",
    "策略集/Make five.js",
    "策略集/Stop five.js",
    "策略集/Make live four.js",
    "策略集/Make four.js",
    "策略集/Stop live four.js",
    "策略集/Make live three.js",
    "策略集/Make live two.js",
    "策略集/Stop live three.js",
    "策略集/Stop four.js",
    "策略集/Stop live two.js",
    "策略集/Make three.js",
    "策略集/Stop live one.js",
    "策略集/Make two.js",
    "策略集/Make one.js",
    "策略集/Stop three.js",
    "策略集/Make live one.js",
    "策略集/Stop two.js",
    "策略集/Stop one.js",
    ""];//*/
var tempSrc;
var head = 0;
var worker;
//棋盘对应棋子
var boardset = [row];
function initSrc()
{
    blackImg.addEventListener("onload", initPre(), false);
    whiteImg.addEventListener("onload", initPre(), false);
    boardImg.addEventListener("onload", initPre(), false);
}
window.onload = function ()
{
    canvas = document.getElementById("canvas");
    canvasVal = canvas.getContext('2d');
    setBoard();
    initSrc();
}
function initPre()
{
    ++cnt;
    canvasVal.clearRect(0, 0, canvas.scrollWidth, 70);
    canvasVal.font = "20px Lucida Handwriting";
    canvasVal.fillStyle = "#ffffff";
    canvasVal.fillText("载入中: " + Math.floor(cnt / totCnt * 100) + "%...", canvas.offsetLeft + canvas.scrollWidth / 3, canvas.offsetTop + 50);
    if (cnt >= totCnt)
    {
        canvasVal.clearRect(0, 0, canvas.scrollWidth, 70);
        timer = setInterval(showBoard, 100);
    }
}
function setBoard()
{
    for (var y = 0; y < row; ++y)
    {
        boardset[y] = [col];
        for (var x = 0; x < col; ++x)
            boardset[y][x] = 0;
    }
}
//显示棋盘
function showBoard()
{
    alp += 0.1;
    canvasVal.globalAlpha = alp;
    canvasVal.fillStyle = "#000000";
    canvasVal.fillRect(0, 0, 650, 700)
    canvasVal.drawImage(boardImg, 0, 0);
    if (alp >= 1.0 && getSrc != null)
    {
        clearInterval(timer);
        canvas.addEventListener('mousedown', showQ, false);
        canvas.addEventListener('mousemove', showPQ, false);
        canvasVal.font = "20px sans-serif";
        canvasVal.fillStyle = "#ffffff";
        canvasVal.fillText(getName, canvas.scrollWidth / 2.5, 650);
        //先调取我方AI
        head = 0;
        tempSrc = getSrc;
        getSrc = mySrc;
        mySrc = tempSrc;
        initWorker();
    }
    if (alp >= 1.0)
        alp = 0.0;
}
//下棋
function showPQ(e)
{
    if (end == true)
        return false;
    var startX = 109;
    var startY = 182;
    var mx = 0;
    var my = 0;
    var ms = 20;
    //判断位置
    if (e.layerX || e.layerX == 0) {
        mx = e.layerX - canvas.offsetLeft - ms;
        my = e.layerY - canvas.offsetTop - ms;
    }
    else if (e.offsetX || e.offsetX == 0) {
        mx = e.offsetX - canvas.offsetLeft - ms;
        my = e.offsetY - canvas.offsetTop - ms;
    }
    //对应棋盘坐标
    var x = Math.floor((mx - startX + 15) / 32.9);
    var y = Math.floor((my - startY + 15) / 32.5);
    //检测显示位置
    if (0 <= x && x < col && 0 <= y && y < row) {
        canvasVal.drawImage(boardImg, 220, 85, 170, 30, 220, 85, 170, 30);
        canvasVal.font = "20px sans-serif";
        canvasVal.fillStyle = "#ffffff";
        var isBlack = "黑棋";
        if (first == 1)
            isBlack = "白棋";
        canvasVal.fillText(isBlack + "(" + (x+1) + "," + String.fromCharCode(y+65) + ")", canvas.scrollWidth / 2.5, 110);
    }
}
function showQ(e)
{
    if (end == true)
        return false;
    var startX = 109;
    var startY = 182;
    var mx = 0;
    var my = 0;
    var ms = 20;
    //判断位置
    if (e.layerX || e.layerX == 0)
    {
        mx = e.layerX - canvas.offsetLeft - ms;
        my = e.layerY - canvas.offsetTop - ms;
    }
    else if (e.offsetX || e.offsetX == 0)
    {
        mx = e.offsetX - canvas.offsetLeft - ms;
        my = e.offsetY - canvas.offsetTop - ms;
    }
    //对应棋盘坐标
    var x = Math.floor((mx - startX + 15) / 32.9);
    var y = Math.floor((my - startY + 15) / 32.5);
    //放棋子
    if (0 <= x && x < col && 0 <= y && y < row && boardset[y][x] == 0)
    {
        boardset[y][x] = first + 1;
        if (first == 0)
            canvasVal.drawImage(blackImg, startX + (x * 32.9) + (Math.random() - 0.5) * 3, startY + (y * 32.5) + (Math.random() - 0.5) * 3);
        else
            canvasVal.drawImage(whiteImg, startX + (x * 32.9) + (Math.random() - 0.5) * 3, startY + (y * 32.5) + (Math.random() - 0.5) * 3);
        judge(x, y);
        first = 1 - first;
        //调AI
        if (end == false && getSrc !== null)
        {
            head = 0;
            tempSrc = getSrc;
            getSrc = mySrc;
            mySrc = tempSrc;
            initWorker();
        }
    }
}
//判断界内
function isIn(x, y)
{
    return (0 <= x && x < col && 0 <= y && y < row);
}
//判断输赢
function judge(x, y)
{
    var dirX = [-1, 0, 1, -1];
    var dirY = [-1, -1, -1, 0];
    for (var i = 0; i < 4; ++i)
    {
        var num = 1;
        for (var j = 1; j < 5; ++j)
        {
            var dx = x + dirX[i]*j;
            var dy = y + dirY[i]*j;
            if (isIn(dx, dy))
            {
                if (boardset[dy][dx] == boardset[y][x])
                    ++num;
                else
                    break;
            }
        }
        for (var j = 1; j < 5; ++j) {
            var dx = x - dirX[i] * j;
            var dy = y - dirY[i] * j;
            if (isIn(dx, dy))
            {
                if (boardset[dy][dx] == boardset[y][x])
                    ++num;
                else
                    break;
            }
        }
        if (num >= 5)
        {
            end = true;
            canvasVal.drawImage(boardImg, 220, 85, 170, 30, 220, 85, 170, 30);
            canvasVal.font = "20px Lucida Handwriting";
            var isBlack = "黑棋手胜利!";
            if (boardset[y][x] == 2)
                isBlack = "白棋手胜利!";
            canvasVal.fillText(isBlack, canvas.scrollWidth / 2.5, 110);
            break;
        }
    }
    Qcnt = 0;
    for (var j = 0; j < row; ++j)
        for (var i = 0; i < col; ++i)
            if (boardset[j][i] > 0)
                ++Qcnt;
    if (Qcnt == row * col)
    {
        end = true;
        canvasVal.drawImage(boardImg, 220, 85, 170, 30, 220, 85, 170, 30);
        canvasVal.font = "20px Lucida Handwriting";
        isBlack = "白棋手胜利!";
        canvasVal.fillText(isBlack, canvas.scrollWidth / 2.5, 110);
    }
}
/////////////////////////AI处理
//接到信息后下棋
function showAI(e)
{
    if (end == true)
        return false;
    //捕获到的消息
    var messageType = e.data.type;
    //消息分类处理
    switch (messageType)
    {
        case ("order"):
            var x = e.data.x;
            var y = e.data.y;
            var who = e.data.who;
            var startX = 109;
            var startY = 182;
            clearTimeout(timer);
            worker.terminate();
             //放棋子
            if (who > 0 && 0 <= x && x < col && 0 <= y && y < row && boardset[y][x] == 0)
            {
                boardset[y][x] = who;
                if (first == 0)
                    canvasVal.drawImage(blackImg, startX + (x * 32.9) + (Math.random() - 0.5) * 3, startY + (y * 32.5) + (Math.random() - 0.5) * 3);
                else
                    canvasVal.drawImage(whiteImg, startX + (x * 32.9) + (Math.random() - 0.5) * 3, startY + (y * 32.5) + (Math.random() - 0.5) * 3);
                judge(x, y);
                first = 1 - first;
                //调取另一方AI
                head = 0;
                tempSrc = getSrc;
                getSrc = mySrc;
                mySrc = tempSrc;
                setTimeout("initWorker()", 700);
            }
            if (who <= 0 && head < getSrc.length - 1)
                initWorker();
        break;
    }
    
}
//初始化Worker
function initWorker()
{
    if (getSrc == null || getSrc[0] == "null")
        return false;
    if (end)
        return false;
    var srcPoint;
    if (head < getSrc.length - 1)
    {
        srcPoint = getSrc[head];
        if (srcPoint == "" || srcPoint == "null")
            return false;
        ++head;
    }
    else
        return false;
    worker = new Worker(srcPoint);
    worker.addEventListener("message", showAI, true);
    worker.addEventListener("error", function (e) { alert(e.message) }, true);
    worker.postMessage({
        'type': 'mes',
        'boardset' : boardset,
        'who' : (first+1)
    });
    timer = setTimeout("handlerTimeout()", 100);
}
//处理超时信息
function handlerTimeout()
{
    worker.terminate();
    canvasVal.drawImage(boardImg, 220, 85, 170, 30, 220, 85, 170, 30);
    canvasVal.font = "20px sans-serif";
    canvasVal.fillStyle = "#ffffff";
    canvasVal.fillText("白棋超时了", canvas.scrollWidth / 2.5, 110);
}
